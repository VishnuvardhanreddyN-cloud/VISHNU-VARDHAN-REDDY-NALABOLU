# Cloud Hello World

A simple cloud project to demonstrate AWS S3, Lambda, and API Gateway.

## Features
- Static website hosted on S3
- API Gateway to expose an endpoint
- Lambda function returns a hello message

## Setup Instructions
1. Upload frontend files to an S3 bucket and enable static hosting.
2. Deploy the Lambda function using AWS Console or CLI.
3. Create an API Gateway and connect it to the Lambda function.
4. Replace `YOUR_API_GATEWAY_URL` in `index.html` with your actual endpoint.

## License
MIT
